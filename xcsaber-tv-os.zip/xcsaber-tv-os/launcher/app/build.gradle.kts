plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xcsaber.tvos"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.xcsaber.tvos"
        // Android 9.0 is API 28. The TV runs Android 9, so this is the floor.
        minSdk = 28
        // Kept at 28 on purpose: matches the TV's OS, avoids newer background-start
        // and package-visibility restrictions that do not exist on the device.
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Intentionally no UI libraries: plain Android views keep the APK tiny
    // and fast on limited TV hardware.
    testImplementation("junit:junit:4.13.2")
}
