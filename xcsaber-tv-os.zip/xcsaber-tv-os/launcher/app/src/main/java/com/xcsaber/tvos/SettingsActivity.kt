package com.xcsaber.tvos

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(80), dp(40), dp(80), dp(40))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF05060C.toInt())
            addView(list)
        })
        build(0)
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTextColor(0x99FFFFFF.toInt())
        setPadding(dp(8), dp(22), 0, dp(6))
    }

    private fun build(focusIndex: Int) {
        list.removeAllViews()
        fun add(v: View) = list.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        var idx = 0
        fun row(title: String, value: String = "", sub: String = "", action: () -> Unit): Int {
            val me = idx++
            add(focusRow(this, title, value, sub) { action(); build(me) })
            return me
        }

        list.addView(TextView(this).apply {
            text = "XCSABER settings"
            textSize = 32f
            setTextColor(Color.WHITE)
        })

        list.addView(title("DISPLAY"))
        row("Screen safe margin", "${prefs.marginPct}%",
            "Adds an empty border so nothing is cut off by TV overscan.") {
            prefs.marginPct = ListOps.cycle(listOf(0, 1, 2, 3, 4, 5), prefs.marginPct)
        }
        row("Alignment guides", onOff(prefs.guides),
            "Red = real screen edge, green = safe margin. Check all four red edges are visible.") {
            prefs.guides = !prefs.guides
        }
        row("24-hour clock", onOff(prefs.clock24)) { prefs.clock24 = !prefs.clock24 }
        row("Screensaver after", if (prefs.screensaverMin == 0) "Off" else "${prefs.screensaverMin} min") {
            prefs.screensaverMin = ListOps.cycle(listOf(0, 5, 10, 15, 30), prefs.screensaverMin)
        }

        list.addView(title("SHELVES ON THE HOME SCREEN"))
        for ((key, label) in listOf(
            "continue" to "Continue", "favorites" to "Favorites", "inputs" to "Inputs",
            "watchlist" to "Watchlist", "library" to "Library", "apps" to "All apps", "system" to "Quick settings"
        )) {
            row(label, onOff(prefs.shelfOn(key))) { prefs.setShelf(key, !prefs.shelfOn(key)) }
        }

        list.addView(title("STARTUP"))
        row("Open XCSABER after power-on", onOff(prefs.launchOnBoot),
            "Off by default. Whether the TV allows this is not guaranteed.") {
            prefs.launchOnBoot = !prefs.launchOnBoot
        }

        list.addView(title("RECOVERY AND TOOLS"))
        row("Return to original launcher", "", "Opens the TV's own home screen.") {
            if (!StockLauncher.open(this)) toast("No other launcher was found on this TV")
        }
        row("Open Android settings") { tryStart(Intent(Settings.ACTION_SETTINGS)) }
        row("About this TV", "", "Hardware report used for the firmware compatibility study.") {
            startActivity(Intent(this, DeviceReportActivity::class.java))
        }
        row("Reset XCSABER settings", "", "Clears favorites, recents, watchlist and options.") {
            AlertDialog.Builder(this).setTitle("Reset all XCSABER settings?")
                .setPositiveButton("Reset") { _, _ -> prefs.clearAll(); build(0) }
                .setNegativeButton("Cancel", null).show()
        }

        // Rows were added after a few non-focusable headings, so find the Nth focusable row.
        val focusables = (0 until list.childCount).map { list.getChildAt(it) }.filter { it.isFocusable }
        focusables.getOrNull(focusIndex)?.post { focusables[focusIndex].requestFocus() }
    }

    private fun onOff(b: Boolean) = if (b) "On" else "Off"
}
