package com.xcsaber.tvos

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaDrm
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.WindowManager
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Phase 1 data collector. READ-ONLY: it only reads values Android already exposes to ordinary apps.
 * It does not collect serial numbers, MAC addresses, IP addresses or account data.
 * Anything the TV does not report is printed as "(not reported)" and must be treated as UNVERIFIED.
 */
object DeviceReport {
    private val PROP_KEYS = listOf(
        "ro.product.manufacturer", "ro.product.brand", "ro.product.model", "ro.product.name",
        "ro.product.device", "ro.product.board", "ro.board.platform", "ro.hardware", "ro.hardware.chipname",
        "ro.boot.hardware", "ro.build.fingerprint", "ro.build.description", "ro.build.flavor",
        "ro.build.type", "ro.build.tags", "ro.build.version.release", "ro.build.version.sdk",
        "ro.build.version.security_patch", "ro.product.first_api_level", "ro.product.cpu.abilist",
        "ro.opengles.version", "ro.sf.lcd_density",
        "ro.build.ab_update", "ro.boot.slot_suffix", "ro.treble.enabled", "ro.vndk.version",
        "ro.build.system_root_image", "ro.boot.dynamic_partitions",
        "ro.boot.verifiedbootstate", "ro.boot.veritymode", "ro.boot.flash.locked",
        "ro.oem_unlock_supported", "sys.oem_unlock_allowed", "ro.boot.bootloader", "ro.bootloader",
        "ro.secure", "ro.debuggable", "ro.adb.secure", "ro.crypto.state", "ro.crypto.type"
    )

    private val FEATURES = listOf(
        "android.software.leanback", "android.hardware.type.television", "android.software.live_tv",
        "android.hardware.hdmi.cec", "android.hardware.touchscreen", "android.hardware.bluetooth",
        "android.hardware.bluetooth_le", "android.hardware.wifi", "android.hardware.ethernet",
        "android.hardware.microphone", "android.software.picture_in_picture"
    )

    private fun allProps(): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            val re = Regex("""\[(.*?)]: \[(.*)]""")
            val p = ProcessBuilder("getprop").redirectErrorStream(true).start()
            p.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { l -> re.matchEntire(l)?.let { map[it.groupValues[1]] = it.groupValues[2] } }
            }
            p.waitFor()
        } catch (e: Exception) {
            // getprop not runnable: sections below will say "(not reported)".
        }
        return map
    }

    private fun readLines(path: String, filter: (String) -> Boolean): List<String> = try {
        File(path).readLines().filter(filter)
    } catch (e: Exception) {
        emptyList()
    }

    @Suppress("DEPRECATION")
    fun build(ctx: Context): String {
        val sb = StringBuilder()
        fun head(t: String) { sb.append("\n== ").append(t).append(" ==\n") }
        fun kv(k: String, v: Any?) {
            val s = v?.toString()
            sb.append(k.padEnd(34)).append(if (s.isNullOrEmpty()) "(not reported)" else s).append('\n')
        }

        sb.append("XCSABER TV OS - device report\n")
        sb.append("Generated: ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).append('\n')
        sb.append("Read-only. Serial numbers, MAC and IP addresses are NOT collected.\n")
        sb.append("\"(not reported)\" means UNVERIFIED, not \"absent\".\n")

        head("Identity (Android Build class)")
        kv("Manufacturer", Build.MANUFACTURER); kv("Brand", Build.BRAND); kv("Model", Build.MODEL)
        kv("Device (codename)", Build.DEVICE); kv("Product", Build.PRODUCT); kv("Board", Build.BOARD)
        kv("Hardware", Build.HARDWARE); kv("Build fingerprint", Build.FINGERPRINT)
        kv("Build id / display", Build.DISPLAY); kv("Build type / tags", "${Build.TYPE} / ${Build.TAGS}")
        kv("Android release", Build.VERSION.RELEASE); kv("SDK level", Build.VERSION.SDK_INT)
        kv("Security patch", Build.VERSION.SECURITY_PATCH); kv("CPU ABIs", Build.SUPPORTED_ABIS.joinToString())

        val props = allProps()
        head("System properties (getprop, readable without root)")
        for (k in PROP_KEYS) kv(k, props[k])

        head("CPU and memory")
        val cpu = readLines("/proc/cpuinfo") {
            it.startsWith("Hardware") || it.startsWith("model name") || it.startsWith("Processor") ||
                it.startsWith("CPU architecture") || it.startsWith("CPU part")
        }.distinct()
        cpu.take(6).forEach { sb.append(it).append('\n') }
        kv("CPU cores (logical)", Runtime.getRuntime().availableProcessors())
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        kv("RAM total (MB)", mi.totalMem / 1024 / 1024)
        kv("Low-RAM device flag", (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).isLowRamDevice)
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            kv("Data storage total (MB)", st.totalBytes / 1024 / 1024)
            kv("Data storage free (MB)", st.availableBytes / 1024 / 1024)
        } catch (e: Exception) {
            kv("Data storage", null)
        }

        head("Display")
        try {
            val d = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
            val dm = android.util.DisplayMetrics()
            d.getRealMetrics(dm)
            kv("Resolution (pixels)", "${dm.widthPixels} x ${dm.heightPixels}")
            kv("Density (dpi)", dm.densityDpi)
            kv("Refresh rate (Hz)", d.refreshRate)
            kv("Supported modes", d.supportedModes.joinToString { "${it.physicalWidth}x${it.physicalHeight}@${it.refreshRate.toInt()}" })
            kv("HDR types (1=DolbyVision 2=HDR10 3=HLG 4=HDR10+)", d.hdrCapabilities?.supportedHdrTypes?.joinToString())
        } catch (e: Exception) {
            kv("Display", null)
        }

        head("TV features exposed to apps")
        val pm = ctx.packageManager
        for (f in FEATURES) kv(f, pm.hasSystemFeature(f))

        head("TV inputs (what the firmware lets apps see)")
        val inputs = Inputs.list(ctx)
        if (inputs.isEmpty()) sb.append("(none exposed to ordinary apps)\n")
        inputs.forEach { sb.append("- ${it.label}  [passthrough=${it.passthrough}]  id=${it.id}\n") }

        head("DRM (Widevine)")
        try {
            val drm = MediaDrm(UUID.fromString("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"))
            kv("Vendor", drm.getPropertyString("vendor"))
            kv("Version", drm.getPropertyString("version"))
            kv("Security level (L1 = HD streaming)", drm.getPropertyString("securityLevel"))
            kv("Max HDCP level", try { drm.getPropertyString("maxHdcpLevel") } catch (e: Exception) { null })
            drm.release()
        } catch (e: Exception) {
            kv("Widevine", "not available (${e.javaClass.simpleName})")
        }

        head("Launchers on this TV (recovery targets)")
        val homes = StockLauncher.candidates(ctx)
        if (homes.isEmpty()) sb.append("WARNING: no other launcher found. Do NOT make XCSABER the default home.\n")
        homes.forEach { sb.append("- ${it.activityInfo.packageName} / ${it.activityInfo.name}\n") }

        head("Hints derived from the values above (not proof)")
        hints(props).forEach { sb.append("* ").append(it).append('\n') }
        sb.append("\nA firmware decision also needs: the SoC vendor's flash tool, a stock image for this exact\n")
        sb.append("hardware revision, and a tested recovery path. See firmware-research/ in the project.\n")
        return sb.toString()
    }

    private fun hints(p: Map<String, String>): List<String> {
        val out = ArrayList<String>()
        val vb = p["ro.boot.verifiedbootstate"]
        out += when (vb) {
            null -> "Verified boot state not reported (many TV SoC vendors do not use Google's boot properties)."
            "green" -> "Verified boot GREEN: bootloader reports locked and stock-signed images. Modified system images would be rejected."
            "orange" -> "Verified boot ORANGE: bootloader reports UNLOCKED. Custom images may be possible, but this is still not proof."
            else -> "Verified boot state: $vb"
        }
        val locked = p["ro.boot.flash.locked"]
        out += when (locked) {
            "1" -> "Flash lock property says LOCKED."
            "0" -> "Flash lock property says UNLOCKED."
            else -> "Flash lock property not reported."
        }
        out += if (p["ro.oem_unlock_supported"] == "1") "OEM unlocking is reported as supported."
        else "OEM unlocking is not reported as supported."
        out += if (p["ro.build.ab_update"] == "true") "A/B (seamless update) partitions reported."
        else "A/B partitions not reported; treat as a single-slot layout."
        out += if (p["ro.treble.enabled"] == "true") "Project Treble reported as enabled (needed for any GSI)."
        else "Project Treble not reported as enabled. A GSI is very unlikely to work."
        val first = p["ro.product.first_api_level"]?.toIntOrNull()
        if (first != null && first < 26) out += "Shipped with API $first (before Treble became mandatory at API 26)."
        return out
    }

    fun save(ctx: Context, text: String): String? = try {
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val f = File(dir, "xcsaber-device-report.txt")
        f.writeText(text)
        f.absolutePath
    } catch (e: Exception) {
        null
    }
}

class DeviceReportActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 15f
            setTextColor(0xFFE6E9F5.toInt())
            setPadding(dp(48), dp(32), dp(48), dp(48))
            text = "Collecting device information..."
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(0xFF05060C.toInt())
            isFocusable = true
            isFocusableInTouchMode = true
            addView(tv)
        }
        setContentView(sv)
        sv.requestFocus()
        Thread {
            val report = DeviceReport.build(applicationContext)
            val path = DeviceReport.save(applicationContext, report)
            runOnUiThread {
                if (!isDestroyed) {
                    tv.text = (if (path != null) "Saved to: $path\nUse Up/Down on the remote to scroll.\n\n" else "") + report
                }
            }
        }.start()
    }
}
