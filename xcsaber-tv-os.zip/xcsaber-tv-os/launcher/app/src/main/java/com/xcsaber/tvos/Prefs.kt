package com.xcsaber.tvos

import android.content.Context
import org.json.JSONArray

/** All local settings. Stored only on the TV, in app-private storage. Nothing is sent anywhere. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("xcsaber", Context.MODE_PRIVATE)

    private fun list(key: String): List<String> {
        val s = sp.getString(key, null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun putList(key: String, v: List<String>, sync: Boolean = false) {
        val ed = sp.edit().putString(key, JSONArray(v).toString())
        if (sync) ed.commit() else ed.apply()
    }

    val favorites: List<String> get() = list("fav")
    fun toggleFavorite(pkg: String): Boolean {
        val next = ListOps.toggle(favorites, pkg)
        putList("fav", next)
        return pkg in next
    }

    val recents: List<String> get() = list("recent")
    fun pushRecent(pkg: String) = putList("recent", ListOps.pushRecent(recents, pkg, 12))

    val watchlist: List<WatchEntry> get() = list("watch").mapNotNull { WatchEntry.decode(it) }
    fun addWatch(e: WatchEntry) = putList("watch", list("watch") + e.encode())
    fun removeWatch(e: WatchEntry) = putList("watch", list("watch").filter { it != e.encode() })

    var screensaverMin: Int
        get() = sp.getInt("ss_min", 10)
        set(v) = sp.edit().putInt("ss_min", v).apply()

    /** Extra empty border (in percent of screen size) to compensate for TV overscan. */
    var marginPct: Int
        get() = sp.getInt("margin_pct", 2)
        set(v) = sp.edit().putInt("margin_pct", v).apply()

    var guides: Boolean
        get() = sp.getBoolean("guides", false)
        set(v) = sp.edit().putBoolean("guides", v).apply()

    var clock24: Boolean
        get() = sp.getBoolean("clock24", false)
        set(v) = sp.edit().putBoolean("clock24", v).apply()

    var launchOnBoot: Boolean
        get() = sp.getBoolean("boot", false)
        set(v) = sp.edit().putBoolean("boot", v).apply()

    fun shelfOn(key: String): Boolean = sp.getBoolean("shelf_$key", true)
    fun setShelf(key: String, on: Boolean) = sp.edit().putBoolean("shelf_$key", on).apply()

    // ---- crash recovery (written synchronously: the process is about to die) ----
    fun crashTimes(): List<Long> = list("crashes").mapNotNull { it.toLongOrNull() }
    fun addCrash(now: Long) =
        putList("crashes", (crashTimes() + now).takeLast(10).map { it.toString() }, sync = true)

    var safeMode: Boolean
        get() = sp.getBoolean("safe_mode", false)
        set(v) {
            sp.edit().putBoolean("safe_mode", v).commit()
        }

    fun clearAll() = sp.edit().clear().apply()
}
