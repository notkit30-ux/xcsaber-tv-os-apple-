package com.xcsaber.tvos

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

/** Starts an activity and shows a friendly message instead of crashing when the TV lacks it. */
fun Context.tryStart(intent: Intent, failMsg: String = "Not available on this TV"): Boolean =
    try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        toast(failMsg)
        false
    }

object Palette {
    /** Stable, pleasant accent colour derived from any string (package name, title...). */
    fun accentFor(key: String): Int {
        val hue = Math.abs(key.hashCode() % 360).toFloat()
        return Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.9f))
    }

    fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
}

private fun rowBg(ctx: Context, focused: Boolean) = GradientDrawable().apply {
    cornerRadius = ctx.dpf(12f)
    setColor(if (focused) 0x33FFFFFF else 0x0DFFFFFF)
    if (focused) setStroke(ctx.dp(2), Color.WHITE)
}

/** A remote-friendly list row: focusable, highlights when focused, runs [onClick] on OK. */
fun focusRow(
    ctx: Context,
    title: String,
    value: String = "",
    sub: String = "",
    onClick: () -> Unit
): LinearLayout {
    val row = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(ctx.dp(20), ctx.dp(14), ctx.dp(20), ctx.dp(14))
        isFocusable = true
        isClickable = true
        background = rowBg(ctx, false)
        setOnClickListener { onClick() }
        setOnFocusChangeListener { v, f -> v.background = rowBg(ctx, f) }
    }
    val left = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    left.addView(TextView(ctx).apply {
        text = title
        textSize = 20f
        setTextColor(Color.WHITE)
    })
    if (sub.isNotEmpty()) {
        left.addView(TextView(ctx).apply {
            text = sub
            textSize = 14f
            setTextColor(0x99FFFFFF.toInt())
        })
    }
    row.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    if (value.isNotEmpty()) {
        row.addView(TextView(ctx).apply {
            text = value
            textSize = 20f
            setTextColor(0xFF9DB2FF.toInt())
        })
    }
    return row
}
