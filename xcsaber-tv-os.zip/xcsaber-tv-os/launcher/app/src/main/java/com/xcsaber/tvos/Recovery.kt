package com.xcsaber.tvos

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo

/** Finds and opens the TV's original launcher. This is the "way back" required by the project rules. */
object StockLauncher {
    fun candidates(ctx: Context): List<ResolveInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return ctx.packageManager.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
    }

    fun open(ctx: Context): Boolean {
        val c = candidates(ctx)
        if (c.isEmpty()) return false
        val best = c.firstOrNull { (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 }
            ?: c.first()
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .setComponent(ComponentName(best.activityInfo.packageName, best.activityInfo.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}

object CrashGuard {
    /** Records a crash. Returns true when it is the second crash within two minutes. */
    fun record(ctx: Context): Boolean {
        val p = Prefs(ctx)
        val now = System.currentTimeMillis()
        p.addCrash(now)
        val fallBack = CrashPolicy.shouldFallBack(p.crashTimes(), now, 120_000L, 2)
        if (fallBack) p.safeMode = true
        return fallBack
    }
}

class XcApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                if (CrashGuard.record(this)) StockLauncher.open(this)
            } catch (_: Throwable) {
                // Never let the safety net itself cause a second crash.
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
