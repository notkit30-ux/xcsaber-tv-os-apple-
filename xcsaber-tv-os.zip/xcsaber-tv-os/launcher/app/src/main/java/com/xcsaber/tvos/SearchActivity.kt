package com.xcsaber.tvos

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

/** Searches installed apps, watchlist titles and TV inputs. Everything stays on the TV. */
class SearchActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var results: LinearLayout
    private var apps: List<AppItem> = emptyList()
    private var inputs: List<InputItem> = emptyList()
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val input = EditText(this).apply {
            hint = "Search apps, watchlist and inputs"
            textSize = 26f
            setTextColor(Color.WHITE)
            setHintTextColor(0x80FFFFFF.toInt())
            setSingleLine()
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(80), dp(40), dp(80), dp(40))
            addView(input, LinearLayout.LayoutParams(-1, -2))
            addView(ScrollView(context).apply { addView(results) }, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        page.setBackgroundColor(0xFF05060C.toInt())
        setContentView(page)

        Thread {
            val a = AppRepository.load(applicationContext)
            val i = Inputs.list(applicationContext)
            ui.post {
                if (!isDestroyed) {
                    apps = a
                    inputs = i
                    render(input.text.toString())
                }
            }
        }.start()

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = render(s?.toString().orEmpty())
        })
    }

    private fun render(q: String) {
        results.removeAllViews()
        fun add(title: String, sub: String, action: () -> Unit) =
            results.addView(
                focusRow(this, title, "", sub, action),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
            )

        apps.filter { SearchMatch.matches(it.label, q) }.forEach { a ->
            add(a.label, "App") { AppRepository.launch(this, a, prefs); finish() }
        }
        prefs.watchlist.filter { SearchMatch.matches(it.title, q) }.forEach { w ->
            val app = apps.firstOrNull { it.pkg == w.pkg }
            add(w.title, if (app != null) "Watchlist, opens ${app.label}" else "Watchlist") {
                if (app != null) { AppRepository.launch(this, app, prefs); finish() } else toast("No app linked to this title")
            }
        }
        inputs.filter { it.passthrough && SearchMatch.matches(it.label, q) }.forEach { i ->
            add(i.label, "TV input") { Inputs.open(this, i); finish() }
        }
        if (q.isNotBlank() && results.childCount == 0) {
            add("No matches", "Nothing installed or saved matches \"$q\"") {}
        }
    }
}
