package com.xcsaber.tvos

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.provider.MediaStore

data class AppItem(val label: String, val pkg: String, val component: ComponentName, val icon: Drawable?)

object AppRepository {
    /** Lists launchable apps. TV (leanback) apps first, then ordinary launcher apps. Skips ourselves. */
    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppItem>()
        fun scan(category: String) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val ai = ri.activityInfo
                if (ai.packageName == ctx.packageName) continue
                if (!seen.add(ai.packageName)) continue
                val icon: Drawable? = try {
                    ai.loadBanner(pm) ?: ai.loadIcon(pm)
                } catch (e: Exception) {
                    null
                }
                out.add(AppItem(ri.loadLabel(pm).toString(), ai.packageName, ComponentName(ai.packageName, ai.name), icon))
            }
        }
        scan(Intent.CATEGORY_LEANBACK_LAUNCHER)
        scan(Intent.CATEGORY_LAUNCHER)
        return out.sortedBy { it.label.lowercase() }
    }

    fun launch(ctx: Context, item: AppItem, prefs: Prefs) {
        prefs.pushRecent(item.pkg)
        val i = Intent(Intent.ACTION_MAIN)
            .setComponent(item.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        ctx.tryStart(i, "Could not open ${item.label}")
    }
}

data class InputItem(val id: String, val label: String, val passthrough: Boolean)

object Inputs {
    /** TV inputs the firmware exposes. Empty when the TV does not expose them to ordinary apps. */
    fun list(ctx: Context): List<InputItem> = try {
        val m = ctx.getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
        m.tvInputList.map { InputItem(it.id, it.loadLabel(ctx)?.toString() ?: it.id, it.isPassthroughInput) }
    } catch (e: Exception) {
        emptyList()
    }

    fun open(ctx: Context, item: InputItem) {
        val uri = if (item.passthrough) TvContract.buildChannelUriForPassthroughInput(item.id)
        else TvContract.Channels.CONTENT_URI
        ctx.tryStart(Intent(Intent.ACTION_VIEW, uri), "This TV did not accept the input switch request")
    }
}

data class VideoItem(val id: Long, val title: String)

object Library {
    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun recentVideos(ctx: Context, max: Int = 30): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        try {
            ctx.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE),
                null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < max) {
                    out.add(VideoItem(c.getLong(0), c.getString(1) ?: "Video"))
                }
            }
        } catch (e: Exception) {
            // Storage not readable: shelf simply stays empty.
        }
        return out
    }

    fun play(ctx: Context, v: VideoItem) {
        val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v.id)
        ctx.tryStart(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
            "No video player is installed"
        )
    }
}
