package com.xcsaber.tvos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView

class HomeActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var column: LinearLayout
    private lateinit var backdrop: BackdropView
    private lateinit var scroll: ScrollView
    private lateinit var shelves: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var netText: TextView
    private lateinit var clock: TextClock

    private val ui = Handler(Looper.getMainLooper())
    private var apps: List<AppItem> = emptyList()
    private var screensaver: ScreensaverView? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var focusedId: String? = null
    private val idle = Runnable { showScreensaver() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        buildUi()
        if (prefs.safeMode) showSafeModeDialog()
    }

    // ------------------------------------------------------------------ UI skeleton

    private fun buildUi() {
        root = FrameLayout(this)
        backdrop = BackdropView(this)
        root.addView(backdrop, FrameLayout.LayoutParams(-1, -1))

        column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(TextView(this).apply {
            text = "XCSABER"
            textSize = 22f
            letterSpacing = 0.3f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(pill("Search") { startActivity(Intent(this, SearchActivity::class.java)) })
        netText = TextView(this).apply {
            textSize = 16f
            setTextColor(0xCCFFFFFF.toInt())
            setPadding(dp(24), 0, dp(24), 0)
        }
        top.addView(netText)
        clock = TextClock(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
        }
        top.addView(clock)
        column.addView(top)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(26), 0, dp(4))
        }
        heroTitle = TextView(this).apply {
            text = "Welcome"
            textSize = 38f
            setTextColor(Color.WHITE)
            maxLines = 1
        }
        heroSub = TextView(this).apply {
            text = "Loading your apps..."
            textSize = 17f
            setTextColor(0xB3FFFFFF.toInt())
            maxLines = 1
        }
        hero.addView(heroTitle)
        hero.addView(heroSub)
        column.addView(hero)

        shelves = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            addView(shelves, ViewGroup.LayoutParams(-1, -2))
        }
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 16f
        setTextColor(Color.WHITE)
        setPadding(dp(18), dp(8), dp(18), dp(8))
        isFocusable = true
        isClickable = true
        fun bg(f: Boolean) = GradientDrawable().apply {
            cornerRadius = dpf(24f)
            setColor(if (f) 0x40FFFFFF else 0x18FFFFFF)
            setStroke(dp(if (f) 2 else 1), if (f) Color.WHITE else 0x30FFFFFF)
        }
        background = bg(false)
        setOnFocusChangeListener { v, f -> v.background = bg(f) }
        setOnClickListener { onClick() }
    }

    private fun applyMargins() {
        val dm = resources.displayMetrics
        val mx = dm.widthPixels * prefs.marginPct / 100
        val my = dm.heightPixels * prefs.marginPct / 100
        column.setPadding(dp(48) + mx, dp(24) + my, dp(48) + mx, my)
        backdrop.showGuides = prefs.guides
        backdrop.marginX = mx
        backdrop.marginY = my
        backdrop.invalidate()
        val f = if (prefs.clock24) "EEE d MMM   HH:mm" else "EEE d MMM   h:mm a"
        clock.format12Hour = f
        clock.format24Hour = f
    }

    // ------------------------------------------------------------------ shelves

    private fun loadApps() {
        Thread {
            val list = AppRepository.load(applicationContext)
            ui.post {
                if (!isDestroyed) {
                    apps = list
                    rebuildShelves()
                }
            }
        }.start()
    }

    private fun rebuildShelves() {
        shelves.removeAllViews()
        val byPkg = apps.associateBy { it.pkg }
        if (prefs.shelfOn("continue")) {
            addShelf("Continue", prefs.recents.mapNotNull { byPkg[it] }.take(8).map { appTile("continue", it) })
        }
        if (prefs.shelfOn("favorites")) {
            addShelf("Favorites", prefs.favorites.mapNotNull { byPkg[it] }.map { appTile("fav", it) })
        }
        if (prefs.shelfOn("inputs")) {
            addShelf("Inputs", Inputs.list(this).filter { it.passthrough }.map { inputTile(it) })
        }
        if (prefs.shelfOn("watchlist")) addShelf("Watchlist", watchTiles())
        if (prefs.shelfOn("library")) addShelf("Library", libraryTiles())
        if (prefs.shelfOn("apps")) addShelf("All apps", apps.map { appTile("apps", it) })
        if (prefs.shelfOn("system")) addShelf("Quick settings", systemTiles())

        if (shelves.childCount == 0) {
            heroTitle.text = "Nothing to show"
            heroSub.text = "Open XCSABER settings and switch a shelf on."
        } else if (apps.isEmpty()) {
            heroSub.text = "No launchable apps were found."
        }
        restoreFocus()
    }

    private fun addShelf(title: String, tiles: List<Tile>) {
        if (tiles.isEmpty()) return
        shelves.addView(TextView(this).apply {
            text = title
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(0xCCFFFFFF.toInt())
            setPadding(dp(8), dp(16), 0, dp(2))
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        for (t in tiles) {
            val lp = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(8), 0, dp(10), 0) }
            row.addView(TileView(this, t) { onTileFocused(it) }, lp)
        }
        shelves.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            setPadding(dp(8), dp(16), dp(8), dp(12))
            addView(row)
        })
    }

    private fun onTileFocused(t: Tile) {
        focusedId = t.id
        heroTitle.text = t.title
        heroSub.text = t.subtitle
        backdrop.setAccent(t.accent)
    }

    private fun restoreFocus() {
        shelves.post {
            val target = findTile(shelves) { it.tile.id == focusedId } ?: findTile(shelves) { true }
            target?.requestFocus()
        }
    }

    private fun findTile(v: View, pred: (TileView) -> Boolean): TileView? {
        if (v is TileView) return if (pred(v)) v else null
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                findTile(v.getChildAt(i), pred)?.let { return it }
            }
        }
        return null
    }

    // ------------------------------------------------------------------ tiles

    private fun appTile(shelf: String, a: AppItem): Tile {
        val fav = a.pkg in prefs.favorites
        return Tile(
            id = "$shelf:${a.pkg}",
            title = a.label,
            subtitle = if (fav) "In Favorites. Hold OK to remove." else "Hold OK to add to Favorites.",
            icon = a.icon,
            glyph = a.label.take(1).uppercase(),
            accent = Palette.accentFor(a.pkg),
            onClick = { AppRepository.launch(this, a, prefs) },
            onLong = {
                val now = prefs.toggleFavorite(a.pkg)
                toast(if (now) "Added to Favorites" else "Removed from Favorites")
                rebuildShelves()
            }
        )
    }

    private fun inputTile(i: InputItem) = Tile(
        id = "input:${i.id}",
        title = i.label,
        subtitle = "TV input. Works only if this TV accepts the switch request.",
        glyph = "INPUT",
        accent = Palette.accentFor(i.id),
        onClick = { Inputs.open(this, i) }
    )

    private fun watchTiles(): List<Tile> {
        val out = ArrayList<Tile>()
        out.add(Tile(
            id = "watch:add", title = "Add to watchlist", glyph = "+",
            subtitle = "Save a title and the app you watch it in.",
            accent = 0xFF5AC8A8.toInt(), onClick = { addWatchEntry() }
        ))
        for (e in prefs.watchlist) {
            val app = apps.firstOrNull { it.pkg == e.pkg }
            out.add(Tile(
                id = "watch:${e.encode()}", title = e.title,
                subtitle = if (app != null) "Opens ${app.label}. Hold OK to remove." else "No app linked. Hold OK to remove.",
                icon = app?.icon, glyph = e.title.take(1).uppercase(), accent = Palette.accentFor(e.title),
                onClick = {
                    if (app != null) AppRepository.launch(this, app, prefs) else toast("No app linked to this title")
                },
                onLong = {
                    AlertDialog.Builder(this).setTitle("Remove \"${e.title}\"?")
                        .setPositiveButton("Remove") { _, _ -> prefs.removeWatch(e); rebuildShelves() }
                        .setNegativeButton("Keep", null).show()
                }
            ))
        }
        return out
    }

    private fun addWatchEntry() {
        val input = EditText(this).apply {
            hint = "Title, e.g. a film or show"
            setSingleLine()
        }
        AlertDialog.Builder(this).setTitle("Add to watchlist").setView(input)
            .setPositiveButton("Next") { _, _ -> pickWatchApp(input.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun pickWatchApp(title: String) {
        if (title.isEmpty()) return
        val names = (listOf("No app") + apps.map { it.label }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Open \"$title\" with").setItems(names) { _, i ->
            prefs.addWatch(WatchEntry(title, if (i == 0) "" else apps[i - 1].pkg))
            rebuildShelves()
        }.show()
    }

    private fun libraryTiles(): List<Tile> {
        if (!Library.hasPermission(this)) {
            return listOf(Tile(
                id = "lib:allow", title = "Allow video access", glyph = "ALLOW",
                subtitle = "Lets XCSABER list videos stored on this TV or a USB drive.",
                accent = 0xFFF5A623.toInt(),
                onClick = { requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 77) }
            ))
        }
        val vids = Library.recentVideos(this)
        if (vids.isEmpty()) {
            return listOf(Tile(
                id = "lib:none", title = "No videos found", glyph = "EMPTY",
                subtitle = "Videos on internal storage appear here after the TV scans them.",
                onClick = { toast("Nothing to play yet") }
            ))
        }
        return vids.map { v ->
            Tile(
                id = "lib:${v.id}", title = v.title, glyph = "PLAY", subtitle = "Plays in your installed video player.",
                accent = Palette.accentFor(v.title), onClick = { Library.play(this, v) }
            )
        }
    }

    private fun sys(id: String, title: String, sub: String, glyph: String, action: String) = Tile(
        id = "sys:$id", title = title, subtitle = sub, glyph = glyph, accent = Palette.accentFor(id),
        onClick = { tryStart(Intent(action), "$title is not available on this TV") }
    )

    private fun systemTiles(): List<Tile> {
        val out = ArrayList<Tile>()
        out.add(sys("wifi", "Wi-Fi", "Network settings", "Wi-Fi", Settings.ACTION_WIFI_SETTINGS))
        out.add(sys("bt", "Bluetooth", "Pair remotes and speakers", "BT", Settings.ACTION_BLUETOOTH_SETTINGS))
        out.add(sys("display", "Display", "Picture and screen settings", "Display", Settings.ACTION_DISPLAY_SETTINGS))
        out.add(sys("sound", "Sound", "Audio settings", "Sound", Settings.ACTION_SOUND_SETTINGS))
        out.add(sys("android", "Android settings", "All system settings", "Settings", Settings.ACTION_SETTINGS))
        out.add(Tile("sys:xc", "XCSABER settings", "Layout, screensaver, screen margin", glyph = "XC",
            accent = 0xFF6E8CFF.toInt(), onClick = { startActivity(Intent(this, SettingsActivity::class.java)) }))
        out.add(Tile("sys:about", "About this TV", "Hardware report for the compatibility study", glyph = "About",
            accent = 0xFF8E7CFF.toInt(), onClick = { startActivity(Intent(this, DeviceReportActivity::class.java)) }))
        if (StockLauncher.candidates(this).isNotEmpty()) {
            out.add(Tile("sys:stock", "Original launcher", "Go back to the TV's own home screen", glyph = "Back",
                accent = 0xFFFF7A7A.toInt(), onClick = { if (!StockLauncher.open(this)) toast("No other launcher found") }))
        }
        return out
    }

    // ------------------------------------------------------------------ network status

    private fun watchNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        updateNet(cm)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { ui.post { updateNet(cm) } }
            override fun onLost(network: Network) { ui.post { updateNet(cm) } }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { ui.post { updateNet(cm) } }
        }
        try {
            cm.registerDefaultNetworkCallback(cb)
            netCallback = cb
        } catch (e: Exception) {
            // Status text just stays as last read.
        }
    }

    private fun unwatchNetwork() {
        val cb = netCallback ?: return
        try {
            getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb)
        } catch (e: Exception) {
        }
        netCallback = null
    }

    private fun updateNet(cm: ConnectivityManager) {
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val kind = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Online"
        }
        val unvalidated = caps != null && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        netText.text = if (unvalidated) "$kind (no internet?)" else kind
    }

    // ------------------------------------------------------------------ idle, screensaver, keys

    private fun resetIdle() {
        ui.removeCallbacks(idle)
        val m = prefs.screensaverMin
        if (m > 0 && screensaver == null) ui.postDelayed(idle, m * 60_000L)
    }

    private fun showScreensaver() {
        if (screensaver != null) return
        val s = ScreensaverView(this, prefs.clock24)
        screensaver = s
        root.addView(s, FrameLayout.LayoutParams(-1, -1))
    }

    private fun hideScreensaver() {
        screensaver?.let { root.removeView(it) }
        screensaver = null
        resetIdle()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (screensaver != null) {
            if (e.action == KeyEvent.ACTION_DOWN) hideScreensaver()
            return true // the key that wakes the screen does nothing else
        }
        resetIdle()
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_SEARCH) {
            startActivity(Intent(this, SearchActivity::class.java))
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (screensaver != null) { hideScreensaver(); return true }
        resetIdle()
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (screensaver != null) { hideScreensaver(); return true }
        resetIdle()
        return super.dispatchGenericMotionEvent(ev)
    }

    /** Home pressed while already home, or Back pressed: return to the top, never close. */
    private fun goToTop() {
        if (screensaver != null) { hideScreensaver(); return }
        scroll.smoothScrollTo(0, 0)
        findTile(shelves) { true }?.requestFocus()
    }

    override fun onBackPressed() = goToTop()

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        goToTop()
    }

    private fun showSafeModeDialog() {
        AlertDialog.Builder(this)
            .setTitle("XCSABER closed unexpectedly")
            .setMessage("It crashed more than once in a short time. You can go back to the original launcher, or try XCSABER again.")
            .setPositiveButton("Original launcher") { _, _ ->
                if (!StockLauncher.open(this)) toast("No other launcher was found on this TV")
            }
            .setNegativeButton("Try XCSABER") { _, _ -> prefs.safeMode = false }
            .setCancelable(false)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        rebuildShelves()
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onResume() {
        super.onResume()
        applyMargins()
        loadApps()
        watchNetwork()
        resetIdle()
    }

    override fun onPause() {
        ui.removeCallbacks(idle)
        unwatchNetwork()
        screensaver?.let { root.removeView(it) }
        screensaver = null
        super.onPause()
    }
}
