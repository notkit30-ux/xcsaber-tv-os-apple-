package com.xcsaber.tvos

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Opens XCSABER after power-on, but only if the user switched that on in settings (off by default). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == "android.intent.action.QUICKBOOT_POWERON") {
            if (Prefs(context).launchOnBoot) {
                try {
                    context.startActivity(
                        Intent(context, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    // Firmware may block background starts; nothing else to do.
                }
            }
        }
    }
}
