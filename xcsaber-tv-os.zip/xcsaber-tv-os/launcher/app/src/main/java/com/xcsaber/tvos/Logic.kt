package com.xcsaber.tvos

// Pure Kotlin logic with no Android imports, so it can be unit-tested on any JVM.

object ListOps {
    /** Puts [item] first, removes any older copy, and keeps at most [max] entries. */
    fun pushRecent(list: List<String>, item: String, max: Int): List<String> =
        (listOf(item) + list.filter { it != item }).take(max)

    /** Adds [item] if missing, removes it if present. */
    fun toggle(list: List<String>, item: String): List<String> =
        if (item in list) list - item else list + item

    /** Returns the value after [current] in [values], wrapping around. Unknown values give the first. */
    fun cycle(values: List<Int>, current: Int): Int {
        val i = values.indexOf(current)
        return values[(i + 1) % values.size]
    }
}

object SearchMatch {
    /** Case-insensitive "contains" on every word of the query. A blank query matches nothing. */
    fun matches(label: String, query: String): Boolean {
        val words = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return false
        val l = label.lowercase()
        return words.all { l.contains(it) }
    }
}

object CrashPolicy {
    /** True when at least [threshold] crashes happened within the last [windowMs]. */
    fun shouldFallBack(timestamps: List<Long>, now: Long, windowMs: Long, threshold: Int): Boolean =
        timestamps.count { now - it in 0..windowMs } >= threshold
}

data class WatchEntry(val title: String, val pkg: String) {
    fun encode(): String = "$title\u0001$pkg"

    companion object {
        fun decode(s: String): WatchEntry? {
            val parts = s.split('\u0001')
            if (parts.size != 2 || parts[0].isBlank()) return null
            return WatchEntry(parts[0], parts[1])
        }
    }
}
