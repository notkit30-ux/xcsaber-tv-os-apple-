package com.xcsaber.tvos

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import java.util.Random

/** One selectable thing on the home screen (app, input, shortcut, video...). */
data class Tile(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val icon: Drawable? = null,
    val glyph: String = "",
    val accent: Int = 0xFF4C6FFF.toInt(),
    val onClick: () -> Unit,
    val onLong: (() -> Unit)? = null
)

/**
 * Rounded "glass" tile drawn by hand in one View: cheap to draw, no nested layouts,
 * which keeps scrolling smooth on limited TV hardware. No blur is used for the same reason.
 */
class TileView(ctx: Context, val tile: Tile, private val onFocus: (Tile) -> Unit) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val tileW = (224 * d).toInt()
    private val tileH = (126 * d).toInt()
    private val labelH = (30 * d).toInt()
    private val radius = 14 * d

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 22 * d
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 15 * d
    }
    private val rect = RectF(0f, 0f, tileW.toFloat(), tileH.toFloat())
    private val clip = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
    // Each tile gets its own drawable copy: the same app can appear on several shelves.
    private val icon: Drawable? = tile.icon?.constantState?.newDrawable()?.mutate() ?: tile.icon

    init {
        isFocusable = true
        isClickable = true
        isLongClickable = tile.onLong != null
        setOnClickListener { tile.onClick() }
        tile.onLong?.let { cb -> setOnLongClickListener { cb(); true } }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(tileW, tileH + labelH)
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        animate().scaleX(if (gainFocus) 1.1f else 1f).scaleY(if (gainFocus) 1.1f else 1f)
            .setDuration(140).start()
        translationZ = if (gainFocus) 12 * d else 0f
        if (gainFocus) onFocus(tile)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val focused = isFocused
        fill.color = if (focused) 0x38FFFFFF else 0x16FFFFFF
        c.drawRoundRect(rect, radius, radius, fill)

        val ic = icon
        if (ic != null) {
            val iw = ic.intrinsicWidth
            val ih = ic.intrinsicHeight
            if (iw > 0 && ih > 0 && iw.toFloat() / ih > 1.5f) {
                // Wide TV banner: fill the whole rounded tile.
                c.save()
                c.clipPath(clip)
                ic.setBounds(0, 0, tileW, tileH)
                ic.draw(c)
                c.restore()
            } else {
                val s = (64 * d).toInt()
                val l = (tileW - s) / 2
                val t = (tileH - s) / 2
                ic.setBounds(l, t, l + s, t + s)
                ic.draw(c)
            }
        } else if (tile.glyph.isNotEmpty()) {
            val g = TextUtils.ellipsize(tile.glyph, android.text.TextPaint(glyphPaint), tileW - 24 * d, TextUtils.TruncateAt.END)
            c.drawText(g.toString(), tileW / 2f, tileH / 2f + glyphPaint.textSize / 3f, glyphPaint)
        }

        stroke.strokeWidth = if (focused) 3 * d else 1 * d
        stroke.color = if (focused) Color.WHITE else 0x30FFFFFF
        c.drawRoundRect(rect, radius, radius, stroke)

        labelPaint.color = if (focused) Color.WHITE else 0xB3FFFFFF.toInt()
        val label = TextUtils.ellipsize(tile.title, android.text.TextPaint(labelPaint), tileW - 8 * d, TextUtils.TruncateAt.END)
        c.drawText(label.toString(), tileW / 2f, tileH + labelH * 0.72f, labelPaint)
    }
}

/** Dark cinematic backdrop with soft light that gently follows the focused tile's colour. */
class BackdropView(ctx: Context) : View(ctx) {
    private var accent = 0xFF3A55E0.toInt()
    private var anim: ValueAnimator? = null
    private val basePaint = Paint()
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val beamPath = Path()
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    var showGuides = false
    var marginX = 0
    var marginY = 0

    fun setAccent(target: Int) {
        anim?.cancel()
        anim = ValueAnimator.ofObject(ArgbEvaluator(), accent, target).apply {
            duration = 450
            addUpdateListener {
                accent = it.animatedValue as Int
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        basePaint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF0B0D14.toInt(), 0xFF020205.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, basePaint)

        glowPaint.shader = RadialGradient(
            w * 0.82f, h * 0.15f, w * 0.6f,
            intArrayOf(Palette.withAlpha(accent, 120), Palette.withAlpha(accent, 0)), null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, glowPaint)
        glowPaint.shader = RadialGradient(
            w * 0.05f, h * 0.95f, w * 0.5f,
            intArrayOf(Palette.withAlpha(accent, 60), Palette.withAlpha(accent, 0)), null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, glowPaint)

        // One soft diagonal light beam for a cinematic feel.
        beamPath.reset()
        beamPath.moveTo(w * 0.46f, 0f)
        beamPath.lineTo(w * 0.64f, 0f)
        beamPath.lineTo(w * 0.22f, h)
        beamPath.lineTo(w * 0.04f, h)
        beamPath.close()
        beamPaint.shader = LinearGradient(w * 0.5f, 0f, w * 0.1f, h, 0x1CFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawPath(beamPath, beamPaint)

        if (showGuides) {
            val dd = resources.displayMetrics.density
            guidePaint.strokeWidth = 2 * dd
            guidePaint.color = 0xFFFF5A5A.toInt()
            c.drawRect(1 * dd, 1 * dd, w - 1 * dd, h - 1 * dd, guidePaint)
            guidePaint.color = 0xFF5AFF9A.toInt()
            c.drawRect(marginX.toFloat(), marginY.toFloat(), w - marginX, h - marginY, guidePaint)
        }
    }
}

/** Idle screensaver: black screen with a slowly moving clock (avoids burn-in on LCD/OLED). */
class ScreensaverView(ctx: Context, is24h: Boolean) : FrameLayout(ctx) {
    private val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; alpha = 0.85f }
    private val random = Random()
    private val mover = object : Runnable {
        override fun run() {
            moveBox()
            postDelayed(this, 20_000)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        val fmt = if (is24h) "HH:mm" else "h:mm"
        box.addView(TextClock(ctx).apply {
            format12Hour = fmt
            format24Hour = fmt
            textSize = 80f
            setTextColor(0xE6FFFFFF.toInt())
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        box.addView(TextClock(ctx).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 22f
            setTextColor(0x99FFFFFF.toInt())
            gravity = Gravity.START
        })
        addView(box, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun moveBox() {
        val maxX = (width - box.width).coerceAtLeast(1)
        val maxY = (height - box.height).coerceAtLeast(1)
        box.animate().alpha(0f).setDuration(600).withEndAction {
            box.x = random.nextInt(maxX).toFloat()
            box.y = random.nextInt(maxY).toFloat()
            box.animate().alpha(0.85f).setDuration(600).start()
        }.start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(mover)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(mover)
        super.onDetachedFromWindow()
    }
}
