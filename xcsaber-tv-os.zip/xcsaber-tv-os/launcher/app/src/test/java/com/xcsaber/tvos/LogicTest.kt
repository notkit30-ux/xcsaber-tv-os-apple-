package com.xcsaber.tvos

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {
    @Test fun pushRecent_movesToFront_andCaps() {
        assertEquals(listOf("c", "a", "b"), ListOps.pushRecent(listOf("a", "b", "c"), "c", 5))
        assertEquals(listOf("d", "a"), ListOps.pushRecent(listOf("a", "b", "c"), "d", 2))
    }

    @Test fun toggle_addsThenRemoves() {
        val once = ListOps.toggle(emptyList(), "x")
        assertEquals(listOf("x"), once)
        assertEquals(emptyList<String>(), ListOps.toggle(once, "x"))
    }

    @Test fun cycle_wrapsAround() {
        val v = listOf(0, 5, 10)
        assertEquals(5, ListOps.cycle(v, 0))
        assertEquals(0, ListOps.cycle(v, 10))
        assertEquals(0, ListOps.cycle(v, 7)) // unknown value falls back to first
    }

    @Test fun search_requiresAllWords_caseInsensitive() {
        assertTrue(SearchMatch.matches("YouTube Kids", "you kid"))
        assertFalse(SearchMatch.matches("YouTube", "you kid"))
        assertFalse(SearchMatch.matches("Anything", "   "))
    }

    @Test fun crashPolicy_countsOnlyInsideWindow() {
        val now = 1_000_000L
        assertTrue(CrashPolicy.shouldFallBack(listOf(now - 10_000, now - 50_000), now, 120_000, 2))
        assertFalse(CrashPolicy.shouldFallBack(listOf(now - 500_000, now - 50_000), now, 120_000, 2))
    }

    @Test fun watchEntry_roundTrips() {
        val e = WatchEntry("Dune Part Two", "com.example.player")
        assertEquals(e, WatchEntry.decode(e.encode()))
        assertNull(WatchEntry.decode("garbage"))
    }
}
