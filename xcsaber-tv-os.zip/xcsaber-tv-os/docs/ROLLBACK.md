# Rollback and recovery

XCSABER changes no system files, so every step below only affects the app.

## Quick ways back, easiest first

1. **In the app:** Quick settings > **Original launcher** (or XCSABER settings > Return to original launcher).
2. **Home button choice:** if XCSABER was set as the default, Settings > Apps > XCSABER TV OS > **Clear defaults**. The next Home press asks again, or goes to the stock launcher.
3. **Uninstall:** Settings > Apps > XCSABER TV OS > **Uninstall**. The TV is exactly as before.
4. **Automatic:** if XCSABER crashes twice within two minutes it opens the original launcher by itself. On its next start it asks whether to go to the original launcher or try again.
5. **Reset only XCSABER's settings:** XCSABER settings > Reset XCSABER settings.

## If the screen is stuck and the remote cannot reach Settings

Needs a computer, or a phone app that speaks ADB, with network debugging enabled on the TV (Developer options). The exact commands, which only affect this one app:

```
adb connect <TV-IP-ADDRESS>:5555
adb uninstall com.xcsaber.tvos
```

Neither command touches system files. If you cannot do this, unplug the TV for a minute: XCSABER does not auto-start after power-on unless you switched that on in its settings.

## Last resort

A factory reset from the TV's own settings removes sideloaded apps but also erases your accounts and settings. Use it only if nothing above works.

## Firmware

There is no firmware rollback to document because no firmware change is made. See `firmware-research/02-backup-and-recovery-plan.md`.
