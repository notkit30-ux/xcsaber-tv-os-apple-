# Install XCSABER TV OS (beginner guide, phone only)

This installs a normal app. It changes **no** system files. You can remove it at any time (see `ROLLBACK.md`).

Menu names differ between TV makers. Where this guide is not sure, it says so.

## 1. Get the APK

1. Open your GitHub repository on your phone, tap **Actions**, open **Build XCSABER TV OS APK**, tap the newest run.
2. Under **Artifacts** download `xcsaber-tv-os-debug`. It is a zip with `xcsaber-tv-os-debug.apk` and `SHA256SUMS.txt`.
3. Easier for the TV: create a **Release** tagged `v0.1.0`. The workflow attaches the APK there, and the release page gives a normal download link.

If the Actions run is red, copy the error text from the failed step and send it to Claude; fix it before going further.

## 2. Move it to the TV (pick one)

- **Downloader app on the TV** (search for "Downloader" in the TV's app store). Type the release download link. Needs a TV that has an app store.
- **"Send Files to TV"** installed on both phone and TV, same Wi-Fi.
- **USB drive**: copy the APK to the drive on your phone (USB-OTG adapter), plug it in the TV, open a file manager app on the TV.

## 3. Allow installing

When the TV asks, allow **Install unknown apps** for the app you are using (Downloader or the file manager). It is usually under Settings > Device Preferences > Security & restrictions. *Not verified for this TV.*

## 4. Install and open

1. Open the APK and choose **Install**.
2. Find **XCSABER TV OS** in your apps and open it. At this stage it is just an app; your normal home screen is still in charge. This is the safe way to try it.
3. Use the remote: arrows to move, **OK** to open, **hold OK** on an app to add it to Favorites.

## 5. First checks (please do these)

1. Quick settings > **About this TV**. Scroll to the end and read the hints. Take photos of every page with your phone, or copy the saved file, and send them to Claude. This is what unlocks the compatibility study.
2. Quick settings > **XCSABER settings** > turn **Alignment guides** on. You should see a red frame around the whole screen. If any red edge is cut off, raise **Screen safe margin** until all four edges are visible, then turn guides off.
3. Open an app, press **Back**, and confirm you return to XCSABER.
4. Try the **Original launcher** tile. It must take you back to the TV's own home screen. **Do not continue until this works.**

## 6. Optional: use it as the home screen

Only after step 5 passed:

1. Press the remote's **Home** button. If the TV asks which home app to use, choose **XCSABER TV OS** and **Just once**.
2. If it behaves well, repeat and choose **Always**.
3. If no question appears, this TV's firmware keeps its own home screen. That is normal; XCSABER stays a regular app. Do not try to force it.

To go back later: Settings > Apps > XCSABER TV OS > **Clear defaults**, or uninstall.

## Verify the download (optional)

Open `SHA256SUMS.txt` and compare with a SHA-256 checker app on your phone run on the APK. They must match exactly.
