# Known limitations

Nothing below is hidden or faked. Where a feature depends on the TV, it says so.

| Feature | Status |
|---|---|
| App discovery and launch | Implemented. Uses TV (leanback) apps first, then ordinary launcher apps. Untested on the MME TV. |
| D-pad navigation, Back, Home | Implemented. Home/Back return to top; the launcher never closes itself. Untested. |
| Becoming the default home screen | Depends on firmware. Many TV builds fix their own home app and will not offer XCSABER. |
| Open after power-on | Optional, off by default. The TV may block background starts or wake from standby differently. Untested. |
| HDMI / TV input shortcuts | Uses Android's TV input list. Many TVs do not expose inputs to normal apps, in which case the shelf is empty. The switch request may also be refused. Untested. |
| Wi-Fi, Bluetooth, Display, Sound shortcuts | Open Android's standard settings screens. Any the firmware removed show "not available". |
| Media library | Lists videos the TV has already indexed, after a permission prompt. No thumbnails. Plays in whatever video app is installed. |
| Watchlist | A local list of titles you type, each linked to an app. It does not fetch listings, ratings or recommendations from anywhere (no ads and no tracking, by design). |
| Screensaver | Runs only while XCSABER is on screen. It is not the system screensaver. |
| Overscan | Handled by an adjustable empty border (0-5%) and alignment guides. It does not change the TV's own picture size. |
| Custom boot animation | **Not supported.** It needs system partition changes, which this project does not do. |
| Removing or disabling the stock launcher | **Not done**, by rule. |
| Blur effects | Not used. Plain translucent "glass" keeps animations smooth on weak hardware. |
| DRM and streaming apps | Unchanged; they run in their own apps. |
| Performance on this TV | Unmeasured. See `TEST-LOG.md`. |
