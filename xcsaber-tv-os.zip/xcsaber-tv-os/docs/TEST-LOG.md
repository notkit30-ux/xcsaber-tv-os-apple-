# Test log

**Rule: a test is "PASS" only if it was actually performed. Everything else is "NOT RUN".**

## What happened in the build session

- The code was written and read through carefully, but **never compiled**: the build environment had no Android SDK, and its network could not reach Google's SDK servers. Expect the first GitHub Actions run to possibly reveal compile errors; paste the error log and they will be fixed.
- Unit tests exist (`launcher/app/src/test/.../LogicTest.kt`: recents, favorites toggle, setting cycle, search matching, crash window, watchlist encoding). **NOT RUN.**

## Checklist

| Test | Result | Notes |
|---|---|---|
| Unit tests (cloud) | NOT RUN | |
| APK builds in GitHub Actions | NOT RUN | |
| Installs on the MME TV | NOT RUN | |
| Starts without crashing | NOT RUN | |
| Remote navigation (all four arrows, OK, hold OK) | NOT RUN | |
| Open an app and come back with Back | NOT RUN | |
| Home press while on home returns to top | NOT RUN | |
| Screen resolution and overscan (guides) | NOT RUN | |
| Memory use and animation smoothness | NOT RUN | Watch for stutter on focus move and shelf scroll. |
| Network drop and return (status text) | NOT RUN | |
| HDMI input tile appears / switches | NOT RUN | May legitimately show nothing. |
| Audio and display shortcuts open | NOT RUN | |
| Reboot behaviour, with and without "open after power-on" | NOT RUN | |
| Original launcher tile works | NOT RUN | **Must pass before using as default home.** |
| Crash guard falls back to stock launcher | NOT RUN | |
| Uninstall restores previous state | NOT RUN | |

Fill in the table by hand after testing on the TV, with date and what you saw.
