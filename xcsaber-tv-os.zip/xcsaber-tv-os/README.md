# XCSABER TV OS

A premium, ad-free, Apple TV-inspired home screen for an **MME TV running Android 9.0**, with original XCSABER branding and artwork.

> **Honest scope.** What this repository delivers today is a **custom Android TV launcher** (a normal app that can also act as the home screen). It is **not** an operating system, and nothing here flashes, unlocks, roots or modifies the TV's firmware. Whether a deeper replacement is possible for this exact TV is an open research question, tracked in `firmware-research/`, and it is **blocked until the TV's real hardware is identified** (see below).

## Status

| Part | State |
|---|---|
| Launcher source code (Kotlin, Android 9+) | Written. **Not yet compiled or run** (see `docs/TEST-LOG.md`). |
| Cloud APK build (GitHub Actions) | Workflow written. **Not yet run.** |
| Device/firmware compatibility report | **Blocked: hardware unidentified.** The launcher includes an "About this TV" screen that collects the facts needed. |
| Firmware / custom ROM | **Not started, and gated.** See `firmware-research/04-firmware-build-plan.md`. |

## Folders

```
launcher/            The Android app (Gradle project). Launcher source lives only here.
firmware-research/   Hardware report, recovery plan, approach decision, firmware gate. No app code.
docs/                Install guide for beginners, rollback, limitations, test log.
.github/workflows/   Cloud APK build.
```

## What the launcher does

- Dark cinematic home screen, glass-style rounded tiles, colour glow that follows the focused tile, smooth focus animation.
- Shelves: **Continue**, **Favorites** (hold OK on a tile), **Inputs** (HDMI / TV inputs, only if the TV exposes them), **Watchlist** (local), **Library** (local videos, permission asked at runtime), **All apps**, **Quick settings** (Wi-Fi, Bluetooth, Display, Sound, Android settings).
- Search (apps, watchlist, inputs), date/time, network status, idle screensaver with a drifting clock.
- Settings: screen safe margin for overscan, alignment guides, 24-hour clock, shelf on/off, screensaver delay, optional open-after-power-on.
- Back/Home return to the top and never close the launcher. Crash guard: after two crashes in two minutes it opens the TV's original launcher and offers a choice on next start. A tile and a settings row always lead back to the original launcher.
- **About this TV**: read-only hardware report (model, SoC, boot-lock hints, Treble/A-B hints, display, DRM, TV inputs, installed launchers). No serial numbers, MAC or IP addresses.
- No ads, no analytics, no network access except reading connection status. All settings stay on the TV.

Not done on purpose: custom boot animation (needs system partition changes), disabling or removing the stock launcher, rooting, flashing.

## Build the APK without a computer

1. Put the contents of this folder in a GitHub repository (the `.github` folder must stay at the top level).
2. Open the repo's **Actions** tab, run **Build XCSABER TV OS APK** (or push to `main`).
3. Download the `xcsaber-tv-os-debug` artifact. For an easy TV download link, create a release tagged `v0.1.0`; the workflow attaches the APK and a `SHA256SUMS.txt`.

Then follow `docs/INSTALL-BEGINNER.md`.

## Next step

Install it, open **About this TV**, and send the report text back. That fills `firmware-research/01-device-compatibility-report.md` with verified facts and decides whether anything beyond a launcher is worth investigating.

## Licence and artwork

All artwork is original and drawn in code/vector. No Apple assets or code are used; the design only follows general principles (dark, large focus targets, shelves).
