# 03 - Implementation decision

**Recommendation: A - custom Android TV launcher.** It is the only option that is possible today without unverified assumptions, and it is fully reversible.

| Option | What it would give | What it needs | Verdict for this TV |
|---|---|---|---|
| **A. Custom launcher** | Home screen, shelves, search, shortcuts, screensaver. Runs as a normal app. | Nothing special. Sideload an APK. | **Chosen.** Feasible now. |
| B. Privileged system UI replacement | Replace the stock launcher/system UI, hide it, start at boot reliably | Root, a system-partition write or a signed OEM build. | Not feasible without modifying the system. Rejected until recovery exists. |
| C. AOSP / GSI based system | A different Android build | Unlocked bootloader, Treble, matching partition layout, working vendor drivers for panel/tuner/audio/CEC/DRM | Unknown. No evidence the TV supports it. Closed. |
| D. Device-specific custom ROM | Full custom OS | Public source for this board, community support, recovery method | None found. Closed. |

## Honest limits of option A

Can: look and feel of a modern TV home, fast app launching, favorites, recents, local watchlist, local video list, inputs and settings shortcuts where the TV exposes them, recovery to the stock launcher.

Cannot: replace the boot logo/animation, change system settings screens, remove the stock launcher, guarantee it becomes the default home on firmware that locks the home app, add features the hardware lacks, or make DRM apps behave differently.

A launcher is **not** an operating system and this project does not call it one.

## Revisit condition

Reopen options B-D only if `04-firmware-build-plan.md` gate passes.
