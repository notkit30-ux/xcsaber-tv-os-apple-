# 02 - Backup and recovery plan

**Status: NOT SATISFIED. Firmware modification must not start.**

Per the project rules, if no reliable recovery path exists, firmware work stops and only the reversible launcher continues. That is the current situation.

## Required before any root, unlock, flash or partition change

Every line must be ticked, with evidence, for this exact TV model and hardware revision.

- [ ] Owner has read and accepted: warranty may be void; the TV may stop working permanently; data may be erased.
- [ ] TV model, board and SoC verified (`01-device-compatibility-report.md` has no UNVERIFIED rows in identity, boot or partition sections).
- [ ] A complete stock firmware image for this exact revision is in the owner's hands, from the manufacturer or a documented source, with a published checksum.
- [ ] The SoC vendor's flashing tool and the exact steps to enter recovery/upgrade mode are documented for this board, and have been read in full.
- [ ] A backup of the existing firmware or partitions exists and is restorable (not just copied). Its SHA-256 checksum is recorded.
- [ ] A restore has been rehearsed on paper step by step, and the owner knows which cable, USB drive or button combination is needed.
- [ ] Power is stable (TV on a surge protector, no planned interruption), enough free storage on the computer, a known-good USB drive/cable.
- [ ] The owner has typed an explicit confirmation of the exact command shown.

## Checksums

When files exist, record them here, never skip:

```
sha256sum <file>      # Linux / Mac
certutil -hashfile <file> SHA256     # Windows
```

| File | SHA-256 | Source |
|---|---|---|
| (none yet) | | |

## What exists today instead

The launcher has its own rollback (`docs/ROLLBACK.md`). It changes no system files, so removing the app returns the TV to exactly its previous state.
