# 04 - Firmware build plan

**Status: CLOSED. No plan is written because the TV is not demonstrably compatible.**

A firmware plan may be started only when **all** of these are true:

1. `01-device-compatibility-report.md` is fully VERIFIED for identity, SoC, partitions, boot lock.
2. The bootloader is reported unlockable by the manufacturer or by documentation for this exact board, and the unlock procedure is documented.
3. `02-backup-and-recovery-plan.md` is fully ticked.
4. A source tree, vendor blobs or a compatible image for this exact board exists publicly, with licences understood.
5. Drivers for panel, tuner, audio, HDMI/CEC, Wi-Fi, Bluetooth, remote and DRM are known to work with it.
6. The owner approves each destructive step individually.

If any item fails, the answer stays: use the launcher.
