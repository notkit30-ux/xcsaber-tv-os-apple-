# Firmware research (kept separate from the launcher)

Nothing in this folder is code that runs on the TV. It records what is known, unknown and decided about replacing deeper parts of the TV's software.

| File | Purpose | State |
|---|---|---|
| `01-device-compatibility-report.md` | Hardware facts with evidence level | Mostly UNVERIFIED |
| `02-backup-and-recovery-plan.md` | What must exist before any firmware change | Not satisfied |
| `03-implementation-decision.md` | Launcher vs system UI vs GSI vs custom ROM | Decided: launcher |
| `04-firmware-build-plan.md` | Gate checklist for any firmware work | Closed |

## Rules that apply to everything here

- Never flash firmware made for another TV model or chipset.
- Never invent a firmware download, unlock method or recovery procedure. If it is not documented for this exact hardware revision, it does not exist for our purposes.
- Every destructive command is shown to the owner first, with the exact text, and needs a clear yes.
- Evidence levels: **VERIFIED** (read from the TV itself), **SOURCED** (public document linked), **UNVERIFIED** (assumption or general knowledge, not confirmed for this TV).
